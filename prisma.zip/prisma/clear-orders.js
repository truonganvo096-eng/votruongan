// Script xóa toàn bộ đơn hàng (Order, OrderItem, BehaviorLog),
// GIỮ NGUYÊN món ăn, danh mục, tài khoản người dùng.
// Chạy: node prisma/clear-orders.js

const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  console.log("Đang xóa dữ liệu đơn hàng...");

  // Thứ tự xóa quan trọng: xóa bảng con trước, bảng cha sau
  // (OrderItem tham chiếu Order, BehaviorLog tham chiếu User/MenuItem
  //  nhưng không tham chiếu Order nên xóa độc lập cũng được)
  const deletedOrderItems = await prisma.orderItem.deleteMany();
  const deletedOrders = await prisma.order.deleteMany();
  const deletedLogs = await prisma.behaviorLog.deleteMany();

  console.log(`Đã xóa ${deletedOrderItems.count} dòng OrderItem`);
  console.log(`Đã xóa ${deletedOrders.count} đơn hàng`);
  console.log(`Đã xóa ${deletedLogs.count} log hành vi`);
  console.log("Hoàn tất! Món ăn và tài khoản vẫn được giữ nguyên.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
