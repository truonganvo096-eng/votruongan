const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");
const prisma = new PrismaClient();

async function main() {
  console.log("Đang xóa dữ liệu cũ...");
  await prisma.behaviorLog.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.menuItem.deleteMany();
  await prisma.category.deleteMany();
  await prisma.user.deleteMany();

  console.log("Tạo tài khoản mẫu...");
  const adminPassword = await bcrypt.hash("admin123", 10);
  const customerPassword = await bcrypt.hash("customer123", 10);

  const admin = await prisma.user.create({
    data: { name: "Quản trị viên", email: "admin@shop.com", password: adminPassword, role: "admin" },
  });
  const customer = await prisma.user.create({
    data: { name: "Khách hàng Demo", email: "customer@shop.com", password: customerPassword, role: "customer" },
  });

  console.log("Tạo danh mục...");
  const monNuoc = await prisma.category.create({ data: { name: "Món nước" } });
  const monKho = await prisma.category.create({ data: { name: "Món khô" } });
  const doUong = await prisma.category.create({ data: { name: "Đồ uống" } });
  const anVat = await prisma.category.create({ data: { name: "Ăn vặt" } });

  console.log("Tạo thực đơn...");
  const items = await Promise.all([
    prisma.menuItem.create({ data: { name: "Phở bò", description: "Phở bò truyền thống", price: 45000, categoryId: monNuoc.id, imageUrl: "", stockQuantity: 50 } }),
    prisma.menuItem.create({ data: { name: "Bún bò Huế", description: "Bún bò cay đậm đà", price: 42000, categoryId: monNuoc.id, imageUrl: "", stockQuantity: 50 } }),
    prisma.menuItem.create({ data: { name: "Hủ tiếu", description: "Hủ tiếu Nam Vang", price: 40000, categoryId: monNuoc.id, imageUrl: "", stockQuantity: 50 } }),
    prisma.menuItem.create({ data: { name: "Cơm gà", description: "Cơm gà xối mỡ", price: 38000, categoryId: monKho.id, imageUrl: "", stockQuantity: 50 } }),
    prisma.menuItem.create({ data: { name: "Cơm sườn", description: "Cơm sườn nướng", price: 40000, categoryId: monKho.id, imageUrl: "", stockQuantity: 50 } }),
    prisma.menuItem.create({ data: { name: "Bánh mì thịt", description: "Bánh mì thịt nguội", price: 20000, categoryId: monKho.id, imageUrl: "", stockQuantity: 50 } }),
    prisma.menuItem.create({ data: { name: "Trà đá", description: "Trà đá mát lạnh", price: 5000, categoryId: doUong.id, imageUrl: "", stockQuantity: 100 } }),
    prisma.menuItem.create({ data: { name: "Trà tắc", description: "Trà tắc chua ngọt", price: 15000, categoryId: doUong.id, imageUrl: "", stockQuantity: 100 } }),
    prisma.menuItem.create({ data: { name: "Nước cam", description: "Cam vắt nguyên chất", price: 20000, categoryId: doUong.id, imageUrl: "", stockQuantity: 100 } }),
    prisma.menuItem.create({ data: { name: "Quẩy", description: "Quẩy giòn", price: 10000, categoryId: anVat.id, imageUrl: "", stockQuantity: 80 } }),
    prisma.menuItem.create({ data: { name: "Chả giò", description: "Chả giò chiên giòn", price: 25000, categoryId: anVat.id, imageUrl: "", stockQuantity: 80 } }),
  ]);

  const [phoBo, bunBoHue, huTieu, comGa, comSuon, banhMi, traDa, traTac, nuocCam, quay, chaGio] = items;

  console.log("Tạo lịch sử đơn hàng mô phỏng (để module AI có dữ liệu)...");
  // Quy luật mô phỏng:
  // - Phở bò thường đi kèm Trà đá (~75%) hoặc Quẩy (~30%)
  // - Cơm gà thường đi kèm Trà tắc (~60%)
  // - Bánh mì thường đi kèm Nước cam (~50%)
  const rules = [
    { main: phoBo, side: traDa, prob: 0.75 },
    { main: phoBo, side: quay, prob: 0.3 },
    { main: bunBoHue, side: traDa, prob: 0.6 },
    { main: comGa, side: traTac, prob: 0.6 },
    { main: comSuon, side: traTac, prob: 0.4 },
    { main: banhMi, side: nuocCam, prob: 0.5 },
    { main: huTieu, side: chaGio, prob: 0.35 },
  ];

  for (const rule of rules) {
    for (let i = 0; i < 25; i++) {
      const orderItemsData = [{ menuItemId: rule.main.id, quantity: 1, subtotal: rule.main.price }];
      const logsData = [{ userId: customer.id, menuItemId: rule.main.id, actionType: "purchase" }];

      if (Math.random() < rule.prob) {
        orderItemsData.push({ menuItemId: rule.side.id, quantity: 1, subtotal: rule.side.price });
        logsData.push({ userId: customer.id, menuItemId: rule.side.id, actionType: "purchase" });
      }

      const total = orderItemsData.reduce((sum, i) => sum + i.subtotal, 0);

      await prisma.order.create({
        data: {
          userId: customer.id,
          status: "completed",
          total,
          items: { create: orderItemsData },
        },
      });

      await prisma.behaviorLog.createMany({ data: logsData });
    }
  }

  console.log("Hoàn tất seed dữ liệu!");
  console.log("Tài khoản admin: admin@shop.com / admin123");
  console.log("Tài khoản khách: customer@shop.com / customer123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
