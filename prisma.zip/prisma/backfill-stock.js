// Script AN TOÀN: chỉ điền số lượng tồn kho cho món ăn nào đang bị thiếu (0 hoặc null),
// KHÔNG xóa bất kỳ dữ liệu nào khác (đơn hàng, tài khoản, log hành vi đều được giữ nguyên).
// Chạy: node prisma/backfill-stock.js

const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  const items = await prisma.menuItem.findMany();
  console.log(`Tìm thấy ${items.length} món ăn.`);

  let updated = 0;
  for (const item of items) {
    // Chỉ cập nhật món nào đang có tồn kho = 0 (mặc định lúc mới thêm cột)
    if (!item.stockQuantity || item.stockQuantity === 0) {
      await prisma.menuItem.update({
        where: { id: item.id },
        data: { stockQuantity: 50 }, // mặc định cấp 50 phần, bạn có thể sửa số này
      });
      updated++;
      console.log(`  → Đã cấp 50 phần tồn kho cho "${item.name}"`);
    }
  }

  console.log(`Hoàn tất! Đã cập nhật tồn kho cho ${updated}/${items.length} món.`);
  console.log("Toàn bộ đơn hàng, tài khoản, dữ liệu khác được giữ nguyên.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
