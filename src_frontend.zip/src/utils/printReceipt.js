// In hóa đơn bằng một <iframe> ẩn nhúng ngay trong trang (không mở cửa sổ/tab mới).
// Cách này không bị trình duyệt coi là "popup" nên không cần xin quyền, và vẫn chạy
// được kể cả khi lệnh in được gọi tự động (không phải do người dùng bấm chuột trực tiếp) —
// điều mà window.open() không làm được trong trường hợp tự in sau khi admin xác nhận thanh toán.
export function printReceipt(order) {
  const orderCode = order.id.slice(0, 8).toUpperCase();
  const dateStr = new Date(order.createdAt).toLocaleString("vi-VN");

  const itemsRows = order.items
    .map(
      (i) => `
      <tr>
        <td>${i.menuItem.name}</td>
        <td class="center">${i.quantity}</td>
        <td class="right">${i.subtotal.toLocaleString()}đ</td>
      </tr>`
    )
    .join("");

  const html = `
    <!DOCTYPE html>
    <html lang="vi">
    <head>
      <meta charset="UTF-8" />
      <title>Hóa đơn #${orderCode}</title>
      <style>
        * { box-sizing: border-box; }
        body {
          font-family: 'Courier New', Consolas, monospace;
          font-size: 13px;
          color: #111;
          padding: 20px;
          max-width: 340px;
          margin: 0 auto;
        }
        h1 { text-align: center; font-size: 18px; margin: 0 0 2px; }
        .subtitle { text-align: center; color: #555; margin: 0 0 10px; }
        hr { border: none; border-top: 1px dashed #999; margin: 10px 0; }
        .row { display: flex; justify-content: space-between; margin: 3px 0; }
        table { width: 100%; border-collapse: collapse; margin: 8px 0; }
        th, td { text-align: left; padding: 4px 2px; font-size: 12px; }
        thead th { border-bottom: 1px solid #999; }
        .center { text-align: center; }
        .right { text-align: right; }
        .total-row { display: flex; justify-content: space-between; font-weight: bold; font-size: 15px; margin-top: 6px; }
        .footer { text-align: center; margin-top: 16px; color: #555; }
        @media print {
          body { padding: 0; }
        }
      </style>
    </head>
    <body>
      <h1>🍜 Gọi Món Ngon</h1>
      <p class="subtitle">Hóa đơn bán hàng</p>
      <hr />
      <div class="row"><span>Mã đơn</span><span>#${orderCode}</span></div>
      <div class="row"><span>Thời gian</span><span>${dateStr}</span></div>
      <hr />
      <table>
        <thead>
          <tr><th>Món</th><th class="center">SL</th><th class="right">T.Tiền</th></tr>
        </thead>
        <tbody>${itemsRows}</tbody>
      </table>
      <hr />
      <div class="total-row"><span>Tổng cộng</span><span>${order.total.toLocaleString()}đ</span></div>
      <p class="footer">Cảm ơn quý khách đã đặt món!</p>
    </body>
    </html>
  `;

  const iframe = document.createElement("iframe");
  // Giấu iframe ở góc màn hình, không hiện lên giao diện nhưng vẫn render/in được
  iframe.style.position = "fixed";
  iframe.style.right = "0";
  iframe.style.bottom = "0";
  iframe.style.width = "0";
  iframe.style.height = "0";
  iframe.style.border = "0";
  document.body.appendChild(iframe);

  function cleanup() {
    if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
  }

  const doc = iframe.contentWindow.document;
  doc.open();
  doc.write(html);
  doc.close();

  iframe.contentWindow.onafterprint = cleanup;

  // Đợi một nhịp cho nội dung render xong rồi mới gọi in
  setTimeout(() => {
    try {
      iframe.contentWindow.focus();
      iframe.contentWindow.print();
    } finally {
      // Phòng khi trình duyệt không bắn sự kiện onafterprint (một số trình duyệt/OS),
      // vẫn dọn dẹp iframe sau một khoảng thời gian hợp lý.
      setTimeout(cleanup, 5000);
    }
  }, 200);
}
