import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import client from "../api/client";
import ReceiptModal from "../components/ReceiptModal";

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, total, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState("");
  const [paidOrder, setPaidOrder] = useState(null); // đơn vừa tạo, đang chờ thanh toán qua QR
  const [showReceipt, setShowReceipt] = useState(false); // hiện popup hóa đơn khi đã xác nhận thanh toán

  // Đợi admin xác nhận đã nhận được tiền (đổi status khỏi "pending") rồi mới hiện hóa đơn.
  // Poll trạng thái đơn mỗi 4 giây trong lúc màn QR đang hiện.
  useEffect(() => {
    if (!paidOrder || paidOrder.status !== "pending") return;

    const interval = setInterval(async () => {
      try {
        const res = await client.get(`/orders/${paidOrder.id}`);
        const updated = res.data.data;
        if (updated.status !== "pending") {
          clearInterval(interval);
          setPaidOrder(updated);
          if (updated.status !== "cancelled") {
            setShowReceipt(true);
          }
        }
      } catch {
        // lỗi mạng tạm thời, lần poll sau thử lại, không cần báo lỗi cho khách
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [paidOrder?.id, paidOrder?.status]);

  async function handleCheckout() {
    if (!user) return navigate("/login");
    setPlacing(true);
    setError("");
    try {
      const items = cart.map((i) => ({ menuItemId: i.menuItem.id, quantity: i.quantity }));
      const res = await client.post("/orders", { items });
      clearCart();
      setPaidOrder(res.data.data);
    } catch (err) {
      setError(err.response?.data?.message || "Đặt món thất bại, thử lại nhé");
    } finally {
      setPlacing(false);
    }
  }

  if (paidOrder) {
    const isPending = paidOrder.status === "pending";

    return (
      <div className="max-w-md mx-auto px-4 py-10 text-center">
        {isPending ? (
          <>
            <h1 className="text-xl font-bold mb-1">Quét mã để thanh toán</h1>
            <p className="text-gray-500 text-sm mb-6">
              Đơn #{paidOrder.id.slice(0, 8).toUpperCase()} — vui lòng chuyển khoản đúng số tiền bên dưới.
              Hóa đơn sẽ tự động in ngay khi cửa hàng xác nhận đã nhận được tiền.
            </p>

            {paidOrder.qrUrl ? (
              <img
                src={paidOrder.qrUrl}
                alt="Mã QR thanh toán"
                className="mx-auto rounded-xl border shadow-sm w-full max-w-xs"
              />
            ) : (
              <p className="text-red-500 text-sm">
                Chưa cấu hình tài khoản ngân hàng nhận thanh toán (thiếu BANK_ID / BANK_ACCOUNT_NO trong .env)
              </p>
            )}
          </>
        ) : paidOrder.status === "cancelled" ? (
          <>
            <h1 className="text-xl font-bold mb-1 text-red-500">Đơn đã bị hủy</h1>
            <p className="text-gray-500 text-sm mb-6">Đơn #{paidOrder.id.slice(0, 8).toUpperCase()} đã bị hủy.</p>
          </>
        ) : (
          <>
            <h1 className="text-xl font-bold mb-1 text-green-600">✅ Đã nhận được thanh toán</h1>
            <p className="text-gray-500 text-sm mb-6">
              Đơn #{paidOrder.id.slice(0, 8).toUpperCase()} đã được xác nhận. Hóa đơn hiện bên dưới.
            </p>
          </>
        )}

        <div className="mt-6 bg-white border rounded-xl p-4 text-left">
          <div className="flex justify-between text-sm text-gray-500">
            <span>Nội dung chuyển khoản</span>
            <span className="font-medium text-gray-800">DH {paidOrder.id.slice(0, 8).toUpperCase()}</span>
          </div>
          <div className="flex justify-between font-semibold text-lg mt-2">
            <span>Số tiền</span>
            <span className="text-brand-600">{paidOrder.total.toLocaleString()}đ</span>
          </div>
        </div>

        <button
          onClick={() => navigate("/orders")}
          className="mt-6 w-full bg-brand-600 text-white py-2.5 rounded-lg hover:bg-brand-700"
        >
          Xem đơn của tôi
        </button>

        {showReceipt && (
          <ReceiptModal order={paidOrder} onClose={() => setShowReceipt(false)} />
        )}
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-10 text-center text-gray-400">
        Giỏ hàng đang trống
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold mb-4">Giỏ hàng</h1>

      <div className="space-y-3">
        {cart.map((i) => (
          <div key={i.menuItem.id} className="bg-white border rounded-xl p-3 flex items-center justify-between">
            <div>
              <p className="font-medium">{i.menuItem.name}</p>
              <p className="text-brand-600 text-sm">{i.menuItem.price.toLocaleString()}đ</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center border rounded-lg">
                <button onClick={() => updateQuantity(i.menuItem.id, i.quantity - 1)} className="px-2 py-1">-</button>
                <span className="px-3">{i.quantity}</span>
                <button onClick={() => updateQuantity(i.menuItem.id, i.quantity + 1)} className="px-2 py-1">+</button>
              </div>
              <button onClick={() => removeFromCart(i.menuItem.id)} className="text-red-500 text-sm">Xóa</button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 bg-white border rounded-xl p-4">
        <div className="flex justify-between font-semibold text-lg">
          <span>Tổng cộng</span>
          <span className="text-brand-600">{total.toLocaleString()}đ</span>
        </div>
        {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
        <button
          onClick={handleCheckout}
          disabled={placing}
          className="mt-4 w-full bg-brand-600 text-white py-2.5 rounded-lg hover:bg-brand-700 disabled:opacity-50"
        >
          {placing ? "Đang đặt món..." : "Đặt món"}
        </button>
      </div>
    </div>
  );
}
