import { useEffect, useState } from "react";
import client from "../api/client";

const STATUS_LABEL = {
  pending: "Chờ xác nhận",
  confirmed: "Đã xác nhận",
  preparing: "Đang chuẩn bị",
  delivering: "Đang giao",
  completed: "Hoàn thành",
  cancelled: "Đã hủy",
};

export default function Orders() {
  const [orders, setOrders] = useState([]);

  function loadOrders() {
    client.get("/orders").then((res) => setOrders(res.data.data));
  }

  useEffect(() => {
    loadOrders(); // gọi ngay lần đầu khi vào trang

    // Polling: tự động gọi lại API mỗi 5 giây để đồng bộ trạng thái
    // với thay đổi mà admin thực hiện ở phía quản trị
    const interval = setInterval(loadOrders, 5000);

    // Dọn dẹp interval khi rời khỏi trang, tránh gọi API "mồ côi"
    // sau khi component đã unmount (rò rỉ bộ nhớ)
    return () => clearInterval(interval);
  }, []);

  if (orders.length === 0) {
    return <div className="max-w-2xl mx-auto px-4 py-10 text-center text-gray-400">Bạn chưa có đơn hàng nào</div>;
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold mb-4">Đơn hàng của tôi</h1>
      <div className="space-y-3">
        {orders.map((o) => (
          <div key={o.id} className="bg-white border rounded-xl p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-500">{new Date(o.createdAt).toLocaleString("vi-VN")}</span>
              <span className="text-xs bg-brand-50 text-brand-700 px-2 py-1 rounded-full">
                {STATUS_LABEL[o.status] || o.status}
              </span>
            </div>
            <ul className="text-sm text-gray-700">
              {o.items.map((it) => (
                <li key={it.id}>{it.menuItem.name} x{it.quantity}</li>
              ))}
            </ul>
            <div className="text-right font-semibold text-brand-600 mt-2">
              {o.total.toLocaleString()}đ
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
