import { useEffect, useState } from "react";
import client from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import RecommendationSection from "../components/RecommendationSection";
import MenuSections from "../components/MenuSections";

function SearchIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
      <path d="M21 21l-4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export default function Home() {
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [activeCategory, setActiveCategory] = useState("");
  const [search, setSearch] = useState("");
  const { user } = useAuth();
  const { addToCart } = useCart();

  useEffect(() => {
    client.get("/categories").then((res) => setCategories(res.data.data));
  }, []);

  useEffect(() => {
    const params = {};
    if (activeCategory) params.category = activeCategory;
    if (search) params.search = search;
    client.get("/menu", { params }).then((res) => setItems(res.data.data));
  }, [activeCategory, search]);

  function handleAdd(item) {
    addToCart(item, 1);
    // Ghi log hành vi "add_to_cart" — dữ liệu này nuôi module gợi ý
    client.post("/behavior", {
      userId: user?.id,
      menuItemId: item.id,
      actionType: "add_to_cart",
    });
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      {/* Banner khuyến mãi */}
      <div className="relative overflow-hidden bg-gradient-to-br from-brand-600 to-brand-700 rounded-3xl px-6 py-7 mb-6 text-white">
        <div className="relative z-10 max-w-md">
          <p className="text-xs font-semibold uppercase tracking-wide text-brand-50/80 mb-1">Ưu đãi hôm nay</p>
          <h2 className="text-2xl font-bold leading-snug mb-1">Đặt món ngay, no bụng liền tay</h2>
          <p className="text-sm text-brand-50/90">Chọn món yêu thích bên dưới và thêm vào giỏ chỉ với 1 chạm</p>
        </div>
        <span className="absolute -right-4 -bottom-6 text-[130px] opacity-20 select-none pointer-events-none leading-none">
          🍜
        </span>
      </div>

      {/* Gợi ý cá nhân hóa */}
      <RecommendationSection type="for-you" userId={user?.id} title="🎯 Gợi ý cho bạn" />

      {/* Ô tìm kiếm */}
      <div className="relative my-4">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
          <SearchIcon />
        </span>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Tìm món ăn..."
          className="w-full border rounded-full pl-11 pr-4 py-3 bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
      </div>

      {/* Danh mục dạng viên, cuộn ngang */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1 -mx-4 px-4">
        <button
          onClick={() => setActiveCategory("")}
          className={`shrink-0 px-5 py-2 rounded-full text-sm font-medium transition ${
            activeCategory === "" ? "bg-brand-600 text-white shadow-md shadow-brand-600/30" : "bg-white border text-gray-600"
          }`}
        >
          Tất cả
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCategory(c.id)}
            className={`shrink-0 px-5 py-2 rounded-full text-sm font-medium transition ${
              activeCategory === c.id ? "bg-brand-600 text-white shadow-md shadow-brand-600/30" : "bg-white border text-gray-600"
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      {/* Danh sách món (giữ MenuSections của bạn) */}
      <MenuSections items={items} grouped={activeCategory === ""} onAdd={handleAdd} />
    </div>
  );
}