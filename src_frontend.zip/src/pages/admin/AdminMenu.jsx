import { useEffect, useState } from "react";
import client from "../../api/client";

const EMPTY_FORM = { name: "", description: "", price: "", categoryId: "", imageUrl: "" };

export default function AdminMenu() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);

  function loadItems() {
    client.get("/menu").then((res) => setItems(res.data.data));
  }

  useEffect(() => {
    loadItems();
    client.get("/categories").then((res) => setCategories(res.data.data));
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    if (editingId) {
      await client.put(`/menu/${editingId}`, form);
    } else {
      await client.post("/menu", form);
    }
    setForm(EMPTY_FORM);
    setEditingId(null);
    loadItems();
  }

  function handleEdit(item) {
    setEditingId(item.id);
    setForm({ name: item.name, description: item.description, price: item.price, categoryId: item.categoryId, imageUrl: item.imageUrl || "" });
    // Cuộn lên đầu trang để thấy form sửa, tránh trường hợp món ở cuối danh sách dài
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleDelete(id) {
    if (!confirm("Xóa món này?")) return;
    await client.delete(`/menu/${id}`);
    loadItems();
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="bg-white border rounded-xl p-4 mb-6 grid grid-cols-2 gap-3">
        <input
          placeholder="Tên món" required value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="border rounded-lg px-3 py-2 col-span-2"
        />
        <input
          placeholder="Mô tả" value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="border rounded-lg px-3 py-2 col-span-2"
        />
        <input
          placeholder="Link ảnh (https://...)" value={form.imageUrl}
          onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
          className="border rounded-lg px-3 py-2 col-span-2"
        />
        {form.imageUrl && (
          <div className="col-span-2 h-32 rounded-lg overflow-hidden bg-gray-100">
            <img
              src={form.imageUrl}
              alt="Xem trước"
              className="w-full h-full object-cover"
              onError={(e) => (e.target.style.display = "none")}
            />
          </div>
        )}
        <input
          type="number" placeholder="Giá" required value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          className="border rounded-lg px-3 py-2"
        />
        <select
          required value={form.categoryId}
          onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
          className="border rounded-lg px-3 py-2"
        >
          <option value="">-- Danh mục --</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <button className="col-span-2 bg-brand-600 text-white py-2 rounded-lg hover:bg-brand-700">
          {editingId ? "Cập nhật món" : "Thêm món mới"}
        </button>
      </form>

      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.id} className="bg-white border rounded-xl p-3 flex justify-between items-center">
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-sm text-gray-500">
                {item.category?.name} · {item.price.toLocaleString()}đ ·{" "}
                <span className={item.stockQuantity === 0 ? "text-red-500 font-medium" : ""}>
                  {item.stockQuantity === 0 ? "Hết hàng" : `Tồn: ${item.stockQuantity}`}
                </span>
              </p>
            </div>
            <div className="flex gap-2 text-sm">
              <button onClick={() => handleEdit(item)} className="text-brand-600">Sửa</button>
              <button onClick={() => handleDelete(item.id)} className="text-red-500">Xóa</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
