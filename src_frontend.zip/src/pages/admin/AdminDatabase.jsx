import { useEffect, useState } from "react";
import client from "../../api/client";

// Định dạng giá trị 1 ô cho dễ đọc
function formatCell(key, value) {
  if (value === null || value === undefined || value === "") {
    return <span className="text-gray-300">—</span>;
  }
  if (typeof value === "boolean") {
    return (
      <span className={value ? "text-green-600" : "text-red-500"}>{value ? "true" : "false"}</span>
    );
  }
  if (key.toLowerCase().includes("createdat") || key.toLowerCase().includes("updatedat")) {
    return new Date(value).toLocaleString("vi-VN");
  }
  // Mã UUID dài -> rút gọn, rê chuột vào để xem đầy đủ
  if (typeof value === "string" && value.length > 30 && /^[0-9a-f-]{30,}$/i.test(value)) {
    return <span title={value} className="font-mono text-xs text-gray-500">{value.slice(0, 8)}…</span>;
  }
  if (typeof value === "number") return value.toLocaleString();
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

export default function AdminDatabase() {
  const [tables, setTables] = useState([]);
  const [active, setActive] = useState(null);
  const [data, setData] = useState({ columns: [], rows: [], total: 0 });
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");

  useEffect(() => {
    client.get("/db/tables").then((res) => {
      setTables(res.data.data);
      setActive(res.data.data[0]?.name ?? null);
    });
  }, []);

  function loadTable(name) {
    setLoading(true);
    client
      .get(`/db/tables/${name}`, { params: { limit: 200 } })
      .then((res) => setData(res.data.data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    if (active) {
      setQ("");
      loadTable(active);
    }
  }, [active]);

  const keyword = q.trim().toLowerCase();
  const rows = keyword
    ? data.rows.filter((r) => JSON.stringify(r).toLowerCase().includes(keyword))
    : data.rows;

  return (
    <div>
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <p className="text-sm text-gray-500">
          Xem dữ liệu thật trong database — <b>chỉ đọc</b>, không thể sửa hay xóa từ trang này.
        </p>
      </div>

      {/* Thanh tab: 7 bảng */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
        {tables.map((t) => (
          <button
            key={t.name}
            onClick={() => setActive(t.name)}
            className={`shrink-0 px-4 py-1.5 rounded-full text-sm ${
              active === t.name ? "bg-brand-600 text-white" : "bg-white border"
            }`}
          >
            {t.name} <span className="opacity-60">({t.count})</span>
          </button>
        ))}
      </div>

      {active && (
        <div className="bg-white border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between gap-3 p-3 border-b flex-wrap">
            <p className="text-sm text-gray-500">
              Bảng <b className="text-gray-800">{active}</b> — hiển thị {rows.length} / {data.total} dòng
            </p>
            <div className="flex items-center gap-2">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Tìm trong bảng..."
                className="border rounded-lg px-3 py-1.5 text-sm"
              />
              <button
                onClick={() => loadTable(active)}
                className="border rounded-lg px-3 py-1.5 text-sm hover:bg-gray-50"
              >
                Tải lại
              </button>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-gray-50">
                <tr>
                  {data.columns.map((c) => (
                    <th key={c} className="text-left font-semibold px-3 py-2 border-b whitespace-nowrap">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i} className="hover:bg-brand-50/50">
                    {data.columns.map((c) => (
                      <td key={c} className="px-3 py-2 border-b whitespace-nowrap">
                        {formatCell(c, row[c])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {!loading && rows.length === 0 && (
              <p className="text-center text-gray-400 py-10">Không có dữ liệu</p>
            )}
            {loading && <p className="text-center text-gray-400 py-10">Đang tải...</p>}
          </div>
        </div>
      )}
    </div>
  );
}
