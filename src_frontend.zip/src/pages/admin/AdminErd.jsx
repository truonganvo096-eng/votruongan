import { useEffect, useRef, useState } from "react";
import mermaid from "mermaid";

// Sơ đồ ERD viết bằng cú pháp Mermaid, khớp với backend/prisma/schema.prisma.
// Sửa trực tiếp ở đây hoặc ngay trên giao diện (nút "Sửa sơ đồ").
const DEFAULT_ERD = `erDiagram
  User ||--o{ Order : "đặt"
  User |o--o{ BehaviorLog : "tạo log"
  Category ||--o{ MenuItem : "chứa"
  MenuItem ||--o{ StockEntry : "được nhập"
  MenuItem ||--o{ OrderItem : "được đặt trong"
  MenuItem ||--o{ BehaviorLog : "bị tác động"
  Order ||--o{ OrderItem : "gồm"

  User {
    string id PK
    string name
    string email UK
    string password
    string role
    datetime createdAt
  }
  Category {
    string id PK
    string name
  }
  MenuItem {
    string id PK
    string name
    string description
    float price
    string imageUrl
    boolean available
    int stockQuantity
    string categoryId FK
  }
    StockEntry {
      string id PK
      string menuItemId FK
      int quantity "dương = nhập, âm = trừ kho"
      string type "in hoặc adjust"
      int unitCost "giá nhập mỗi phần, có thể null"
      string supplier "nhà cung cấp"
      datetime expiryDate "hạn sử dụng, có thể null"
      string note
      datetime createdAt
    }
  Order {
    string id PK
    string userId FK
    string status
    float total
    datetime createdAt
  }
  OrderItem {
    string id PK
    string orderId FK
    string menuItemId FK
    int quantity
    float subtotal
  }
  BehaviorLog {
    string id PK
    string userId FK "có thể null"
    string menuItemId FK
    string actionType
    datetime createdAt
  }
`;

mermaid.initialize({ startOnLoad: false, theme: "neutral", securityLevel: "strict" });

export default function AdminErd() {
  const [code, setCode] = useState(DEFAULT_ERD);
  const [draft, setDraft] = useState(DEFAULT_ERD);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState("");
  const [svg, setSvg] = useState("");
  const counter = useRef(0);

  useEffect(() => {
    let cancelled = false;
    counter.current += 1;
    mermaid
      .render(`erd-${counter.current}`, code)
      .then(({ svg }) => {
        if (!cancelled) {
          setSvg(svg);
          setError("");
        }
      })
      .catch((err) => {
        if (!cancelled) setError(err?.message || "Không vẽ được sơ đồ, hãy kiểm tra cú pháp");
      });
    return () => {
      cancelled = true;
    };
  }, [code]);

  function downloadSvg() {
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "erd.svg";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        <button
          onClick={() => setEditing(!editing)}
          className="px-4 py-1.5 rounded-lg border bg-white text-sm"
        >
          {editing ? "Ẩn trình sửa" : "Sửa sơ đồ"}
        </button>
        <button
          onClick={downloadSvg}
          disabled={!svg}
          className="px-4 py-1.5 rounded-lg bg-brand-600 text-white text-sm disabled:opacity-50"
        >
          Tải về SVG
        </button>
      </div>

      {editing && (
        <div className="mb-4">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            spellCheck={false}
            className="w-full h-64 border rounded-xl p-3 font-mono text-xs"
          />
          <div className="flex gap-2 mt-2">
            <button
              onClick={() => setCode(draft)}
              className="px-4 py-1.5 rounded-lg bg-brand-600 text-white text-sm"
            >
              Vẽ lại
            </button>
            <button
              onClick={() => {
                setDraft(DEFAULT_ERD);
                setCode(DEFAULT_ERD);
              }}
              className="px-4 py-1.5 rounded-lg border bg-white text-sm"
            >
              Khôi phục mặc định
            </button>
          </div>
        </div>
      )}

      {error && <p className="text-sm text-red-500 mb-3">{error}</p>}

      <div className="bg-white border rounded-xl p-4 overflow-x-auto">
        {svg ? (
          <div dangerouslySetInnerHTML={{ __html: svg }} />
        ) : (
          <p className="text-center text-gray-400 py-10">Đang vẽ sơ đồ...</p>
        )}
      </div>
    </div>
  );
}
