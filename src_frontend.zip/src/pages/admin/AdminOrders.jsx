import { useEffect, useState } from "react";
import client from "../../api/client";

const STATUS_OPTIONS = ["pending", "confirmed", "preparing", "delivering", "completed", "cancelled"];
const STATUS_LABEL = {
  pending: "Chờ xác nhận", confirmed: "Đã xác nhận", preparing: "Đang chuẩn bị",
  delivering: "Đang giao", completed: "Hoàn thành", cancelled: "Đã hủy",
};

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);

  function loadOrders() {
    client.get("/orders/all").then((res) => setOrders(res.data.data));
  }

  useEffect(() => {
    loadOrders();

    // Polling: tự động lấy đơn hàng mới nhất mỗi 5 giây,
    // để admin thấy đơn mới của khách mà không cần tự bấm F5
    const interval = setInterval(loadOrders, 5000);
    return () => clearInterval(interval);
  }, []);

  async function handleStatusChange(id, status) {
    await client.put(`/orders/${id}/status`, { status });
    loadOrders();
  }

  return (
    <div className="space-y-3">
      {orders.map((o) => (
        <div key={o.id} className="bg-white border rounded-xl p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium">{o.user?.name}</span>
            <select
              value={o.status}
              onChange={(e) => handleStatusChange(o.id, e.target.value)}
              className="text-sm border rounded-lg px-2 py-1"
            >
              {STATUS_OPTIONS.map((s) => (
                <option key={s} value={s}>{STATUS_LABEL[s]}</option>
              ))}
            </select>
          </div>
          <ul className="text-sm text-gray-600">
            {o.items.map((it) => (
              <li key={it.id}>{it.menuItem.name} x{it.quantity}</li>
            ))}
          </ul>
          <div className="text-right font-semibold text-brand-600 mt-1">
            {o.total.toLocaleString()}đ
          </div>
        </div>
      ))}
      {orders.length === 0 && <p className="text-center text-gray-400 py-10">Chưa có đơn hàng nào</p>}
    </div>
  );
}
