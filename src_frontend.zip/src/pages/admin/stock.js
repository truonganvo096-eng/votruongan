const express = require("express");
const { PrismaClient } = require("@prisma/client");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();
const prisma = new PrismaClient();

const DAY = 24 * 60 * 60 * 1000;
const COVER_DAYS = 7; // gợi ý nhập đủ bán bấy nhiêu ngày

function toPositiveInt(v) {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : null;
}

// POST /api/stock (admin) — nhập thêm hàng
// body: { menuItemId, quantity, unitCost?, supplier?, expiryDate?, note? }
router.post("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { menuItemId, quantity, unitCost, supplier, expiryDate, note } = req.body;
    const qty = toPositiveInt(quantity);
    if (!menuItemId || !qty) {
      return res.status(400).json({ success: false, message: "Số lượng nhập phải là số nguyên lớn hơn 0" });
    }

    let cost = null;
    if (unitCost !== undefined && unitCost !== null && unitCost !== "") {
      cost = Number(unitCost);
      if (!Number.isInteger(cost) || cost < 0) {
        return res.status(400).json({ success: false, message: "Giá nhập không hợp lệ" });
      }
    }

    let expiry = null;
    if (expiryDate) {
      expiry = new Date(expiryDate);
      if (isNaN(expiry.getTime())) {
        return res.status(400).json({ success: false, message: "Hạn sử dụng không hợp lệ" });
      }
    }

    const item = await prisma.menuItem.findUnique({ where: { id: menuItemId } });
    if (!item) return res.status(404).json({ success: false, message: "Không tìm thấy món" });

    // Tạo phiếu + cộng kho trong 1 transaction: lỗi giữa chừng thì không bị lệch số liệu
    const [entry, updated] = await prisma.$transaction([
      prisma.stockEntry.create({
        data: {
          menuItemId,
          quantity: qty,
          type: "in",
          unitCost: cost,
          supplier: supplier || "",
          expiryDate: expiry,
          note: note || "",
        },
      }),
      prisma.menuItem.update({
        where: { id: menuItemId },
        data: { stockQuantity: { increment: qty }, available: true },
      }),
    ]);

    res.json({ success: true, data: { entry, menuItem: updated } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi nhập hàng" });
  }
});

// POST /api/stock/adjust (admin) — trừ kho (hỏng, hao hụt, kiểm kê lệch...)
// body: { menuItemId, quantity (số phần cần TRỪ, dương), reason, note? }
router.post("/adjust", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { menuItemId, quantity, reason, note } = req.body;
    const qty = toPositiveInt(quantity);
    if (!menuItemId || !qty) {
      return res.status(400).json({ success: false, message: "Số lượng trừ phải là số nguyên lớn hơn 0" });
    }
    if (!reason) {
      return res.status(400).json({ success: false, message: "Vui lòng chọn lý do điều chỉnh" });
    }

    const result = await prisma.$transaction(async (tx) => {
      // Chỉ trừ khi đủ hàng (tránh âm kho)
      const r = await tx.menuItem.updateMany({
        where: { id: menuItemId, stockQuantity: { gte: qty } },
        data: { stockQuantity: { decrement: qty } },
      });
      if (r.count === 0) throw new Error("INSUFFICIENT");

      const after = await tx.menuItem.findUnique({ where: { id: menuItemId } });
      await tx.menuItem.update({
        where: { id: menuItemId },
        data: { available: after.stockQuantity > 0 },
      });
      const entry = await tx.stockEntry.create({
        data: {
          menuItemId,
          quantity: -qty,
          type: "adjust",
          note: note ? `${reason} — ${note}` : reason,
        },
      });
      return { entry, stockQuantity: after.stockQuantity };
    });

    res.json({ success: true, data: result });
  } catch (err) {
    if (err.message === "INSUFFICIENT") {
      return res.status(400).json({ success: false, message: "Không đủ tồn kho để trừ" });
    }
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi điều chỉnh kho" });
  }
});

// GET /api/stock (admin) — lịch sử nhập / điều chỉnh gần đây
router.get("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const entries = await prisma.stockEntry.findMany({
      include: { menuItem: true },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    res.json({ success: true, data: entries });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi lấy lịch sử nhập hàng" });
  }
});

// GET /api/stock/insights (admin) — phân tích để hỗ trợ quyết định nhập hàng
// Trả về theo từng món: đã bán 7 ngày, còn đủ bán mấy ngày, gợi ý nhập,
// lần nhập gần nhất, giá nhập gần nhất, hạn sử dụng gần nhất; kèm tổng chi phí nhập 30 ngày
router.get("/insights", requireAuth, requireAdmin, async (req, res) => {
  try {
    const now = Date.now();
    const since7 = new Date(now - 7 * DAY);
    const since30 = new Date(now - 30 * DAY);

    const [items, sales, entries] = await Promise.all([
      prisma.menuItem.findMany(),
      // Đơn đã hủy không tính vào doanh số
      prisma.orderItem.groupBy({
        by: ["menuItemId"],
        _sum: { quantity: true },
        where: { order: { createdAt: { gte: since7 }, status: { not: "cancelled" } } },
      }),
      prisma.stockEntry.findMany({ where: { type: "in" }, orderBy: { createdAt: "desc" } }),
    ]);

    const soldMap = {};
    sales.forEach((s) => (soldMap[s.menuItemId] = s._sum.quantity || 0));

    // Phiếu nhập mới nhất của từng món (entries đã sắp mới -> cũ)
    const lastIn = {};
    const lastExpiry = {};
    let spent30 = 0;
    entries.forEach((e) => {
      if (!lastIn[e.menuItemId]) lastIn[e.menuItemId] = e;
      if (e.expiryDate && !lastExpiry[e.menuItemId]) lastExpiry[e.menuItemId] = e.expiryDate;
      if (e.unitCost != null && e.createdAt >= since30) spent30 += e.quantity * e.unitCost;
    });

    const data = {};
    items.forEach((it) => {
      const sold7 = soldMap[it.id] || 0;
      const avgPerDay = sold7 / 7;
      const daysLeft = avgPerDay > 0 ? it.stockQuantity / avgPerDay : null;
      const suggested = Math.max(0, Math.ceil(avgPerDay * COVER_DAYS - it.stockQuantity));
      const li = lastIn[it.id];
      data[it.id] = {
        sold7,
        avgPerDay: Math.round(avgPerDay * 10) / 10,
        daysLeft: daysLeft === null ? null : Math.round(daysLeft * 10) / 10,
        suggested,
        lastInAt: li ? li.createdAt : null,
        lastInQty: li ? li.quantity : null,
        lastUnitCost: li && li.unitCost != null ? li.unitCost : null,
        expiryDate: lastExpiry[it.id] || null,
      };
    });

    res.json({ success: true, data: { items: data, spent30, coverDays: COVER_DAYS } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi phân tích tồn kho" });
  }
});

module.exports = router;
