import { useEffect, useMemo, useRef, useState } from "react";
import client from "../../api/client";
import FoodImage from "../../components/FoodImage";

const LOW_STOCK = 10; // từ mức này trở xuống là "Sắp hết"
const DAY = 24 * 60 * 60 * 1000;
const REASONS = ["Hỏng / hết hạn", "Hao hụt", "Kiểm kê lệch", "Khác"];
const EMPTY_FORM = { menuItemId: "", quantity: "", unitCost: "", supplier: "", expiryDate: "", reason: REASONS[0], note: "" };

const money = (n) => `${Math.round(n).toLocaleString("vi-VN")}đ`;
const fmtDate = (d) => new Date(d).toLocaleDateString("vi-VN");
const daysUntil = (d) => Math.ceil((new Date(d).getTime() - Date.now()) / DAY);

function statusOf(q) {
  if (q === 0) return { key: "out", label: "Hết hàng", cls: "bg-red-50 text-red-600", bar: "bg-red-400" };
  if (q <= LOW_STOCK) return { key: "low", label: "Sắp hết", cls: "bg-amber-50 text-amber-600", bar: "bg-amber-400" };
  return { key: "ok", label: "Còn hàng", cls: "bg-green-50 text-green-600", bar: "bg-green-500" };
}

function StatCard({ icon, label, value, tone = "text-gray-800" }) {
  return (
    <div className="bg-white border rounded-2xl p-4 shadow-sm flex items-center gap-3">
      <div className="w-11 h-11 rounded-xl bg-brand-50 flex items-center justify-center text-xl shrink-0">{icon}</div>
      <div className="min-w-0">
        <p className="text-xs text-gray-500">{label}</p>
        <p className={`text-xl font-bold leading-tight truncate ${tone}`}>{value}</p>
      </div>
    </div>
  );
}

export default function AdminStock() {
  const [items, setItems] = useState([]);
  const [history, setHistory] = useState([]);
  const [insights, setInsights] = useState({ items: {}, spent30: 0, coverDays: 7 });
  const [mode, setMode] = useState("in"); // in = nhập hàng, adjust = trừ kho
  const [form, setForm] = useState(EMPTY_FORM);
  const [message, setMessage] = useState(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [showAllHistory, setShowAllHistory] = useState(false);
  const formRef = useRef(null);

  function loadAll() {
    // all=1: lấy cả món đã hết hàng để còn nhập thêm được
    client.get("/menu", { params: { all: 1 } }).then((r) => setItems(r.data.data));
    client.get("/stock").then((r) => setHistory(r.data.data));
    client.get("/stock/insights").then((r) => setInsights(r.data.data));
  }
  useEffect(loadAll, []);

  useEffect(() => {
    if (!message) return;
    const t = setTimeout(() => setMessage(null), 3500);
    return () => clearTimeout(t);
  }, [message]);

  const info = (id) => insights.items[id] || {};

  // Món cần nhập gấp: hết/sắp hết, hoặc còn đủ bán <= 2 ngày, hoặc sắp/đã hết hạn mà còn hàng
  function isUrgent(item) {
    const i = info(item.id);
    const lowDays = i.daysLeft != null && i.daysLeft <= 2;
    const expiring = item.stockQuantity > 0 && i.expiryDate && daysUntil(i.expiryDate) <= 3;
    return item.stockQuantity <= LOW_STOCK || lowDays || expiring;
  }

  const stats = useMemo(
    () => ({
      total: items.length,
      portions: items.reduce((s, i) => s + i.stockQuantity, 0),
      value: items.reduce((s, i) => s + i.stockQuantity * i.price, 0),
      low: items.filter((i) => i.stockQuantity > 0 && i.stockQuantity <= LOW_STOCK).length,
      out: items.filter((i) => i.stockQuantity === 0).length,
    }),
    [items]
  );
  const urgentCount = items.filter(isUrgent).length;

  const maxStock = Math.max(50, ...items.map((i) => i.stockQuantity));
  const selected = items.find((i) => i.id === form.menuItemId);
  const qty = Number(form.quantity) || 0;
  const sel = selected ? info(selected.id) : {};

  const visible = items
    .filter((i) => {
      if (filter === "urgent") return isUrgent(i);
      if (filter === "low") return statusOf(i.stockQuantity).key === "low";
      if (filter === "out") return i.stockQuantity === 0;
      return true;
    })
    .filter((i) => i.name.toLowerCase().includes(search.trim().toLowerCase()))
    .sort((a, b) => a.stockQuantity - b.stockQuantity);

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      if (mode === "in") {
        await client.post("/stock", {
          menuItemId: form.menuItemId,
          quantity: form.quantity,
          unitCost: form.unitCost,
          supplier: form.supplier,
          expiryDate: form.expiryDate,
          note: form.note,
        });
        setMessage({ type: "ok", text: `Đã nhập thêm ${qty} phần ${selected?.name || ""}` });
      } else {
        await client.post("/stock/adjust", {
          menuItemId: form.menuItemId,
          quantity: form.quantity,
          reason: form.reason,
          note: form.note,
        });
        setMessage({ type: "ok", text: `Đã trừ ${qty} phần ${selected?.name || ""}` });
      }
      setForm(EMPTY_FORM);
      loadAll();
    } catch (err) {
      setMessage({ type: "err", text: err.response?.data?.message || "Có lỗi xảy ra" });
    }
  }

  function quickRestock(item) {
    setMode("in");
    setForm({ ...form, menuItemId: item.id });
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  const filters = [
    { key: "all", label: "Tất cả", count: stats.total },
    { key: "urgent", label: "Cần nhập gấp", count: urgentCount },
    { key: "low", label: "Sắp hết", count: stats.low },
    { key: "out", label: "Hết hàng", count: stats.out },
  ];
  const shownHistory = showAllHistory ? history : history.slice(0, 6);
  const input = "border rounded-xl px-4 py-2.5 w-full";

  return (
    <div className="space-y-6">
      {/* Thống kê */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard icon="🍽️" label="Tổng số món" value={stats.total} />
        <StatCard icon="📦" label="Tổng phần còn" value={stats.portions} />
        <StatCard icon="💰" label="Giá trị tồn kho (giá bán)" value={money(stats.value)} />
        <StatCard icon="🧾" label="Chi phí nhập 30 ngày" value={money(insights.spent30)} />
        <StatCard icon="⚠️" label="Sắp hết" value={stats.low} tone="text-amber-600" />
        <StatCard icon="⛔" label="Hết hàng" value={stats.out} tone="text-red-600" />
      </div>

      {/* Cảnh báo */}
      {urgentCount > 0 && (
        <button
          onClick={() => setFilter("urgent")}
          className="w-full text-left bg-amber-50 border border-amber-200 text-amber-700 rounded-2xl px-4 py-3 text-sm hover:bg-amber-100"
        >
          ⚠️ <b>{urgentCount} món cần chú ý</b> (sắp hết, bán sắp hết trong 2 ngày hoặc gần hết hạn). Bấm để xem.
        </button>
      )}

      {/* Form */}
      <form ref={formRef} onSubmit={handleSubmit} className="bg-white border rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex gap-2">
            {[
              ["in", "📥 Nhập hàng"],
              ["adjust", "📉 Điều chỉnh (trừ kho)"],
            ].map(([k, label]) => (
              <button
                type="button"
                key={k}
                onClick={() => setMode(k)}
                className={`px-4 py-1.5 rounded-full text-sm ${mode === k ? "bg-brand-600 text-white" : "bg-white border"}`}
              >
                {label}
              </button>
            ))}
          </div>
          {message && (
            <span className={`text-sm px-3 py-1 rounded-full ${message.type === "ok" ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"}`}>
              {message.text}
            </span>
          )}
        </div>

        <select required value={form.menuItemId} onChange={(e) => setForm({ ...form, menuItemId: e.target.value })} className={input}>
          <option value="">-- Chọn món --</option>
          {items.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name} (đang còn {item.stockQuantity} phần)
            </option>
          ))}
        </select>

        {/* Gợi ý số lượng nhập dựa trên doanh số */}
        {mode === "in" && selected && sel.suggested > 0 && (
          <button
            type="button"
            onClick={() => setForm({ ...form, quantity: String(sel.suggested) })}
            className="text-sm bg-brand-50 border border-brand-500/30 text-brand-700 rounded-xl px-4 py-2 w-full text-left hover:bg-orange-100"
          >
            💡 Gợi ý: nhập <b>{sel.suggested} phần</b> để đủ bán {insights.coverDays} ngày (đang bán ~{sel.avgPerDay} phần/ngày). Bấm để điền.
          </button>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <input type="number" min="1" step="1" required placeholder={mode === "in" ? "Số lượng nhập thêm" : "Số lượng cần trừ"} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} className={input} />
            {mode === "in" && (
              <div className="flex gap-2 mt-2">
                {[10, 20, 50].map((n) => (
                  <button type="button" key={n} onClick={() => setForm({ ...form, quantity: String(qty + n) })} className="text-xs px-3 py-1 rounded-full border hover:bg-brand-50 hover:border-brand-500">
                    +{n}
                  </button>
                ))}
                <button type="button" onClick={() => setForm({ ...form, quantity: "" })} className="text-xs px-3 py-1 rounded-full text-gray-400 hover:text-gray-600">
                  Xóa
                </button>
              </div>
            )}
          </div>

          {mode === "in" ? (
            <input type="number" min="0" step="1" placeholder="Giá nhập mỗi phần (đ)" value={form.unitCost} onChange={(e) => setForm({ ...form, unitCost: e.target.value })} className={`${input} h-fit`} />
          ) : (
            <select value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} className={`${input} h-fit`}>
              {REASONS.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          )}

          {mode === "in" && (
            <>
              <input placeholder="Nhà cung cấp (VD: Chợ đầu mối)" value={form.supplier} onChange={(e) => setForm({ ...form, supplier: e.target.value })} className={input} />
              <div>
                <input type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} className={input} />
                <p className="text-xs text-gray-400 mt-1 ml-1">Hạn sử dụng (không bắt buộc)</p>
              </div>
            </>
          )}
          <input placeholder="Ghi chú" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} className={`${input} md:col-span-2`} />
        </div>

        {/* Xem trước */}
        {selected && qty > 0 && mode === "in" && (
          <div className="bg-brand-50 border border-brand-500/30 rounded-xl px-4 py-2.5 text-sm">
            <b>{selected.name}</b>: {selected.stockQuantity} → <b className="text-brand-600">{selected.stockQuantity + qty}</b> phần
            {form.unitCost !== "" && <> · Thành tiền: <b>{money(qty * Number(form.unitCost))}</b></>}
          </div>
        )}
        {selected && qty > 0 && mode === "adjust" && (
          <div className={`rounded-xl px-4 py-2.5 text-sm border ${qty > selected.stockQuantity ? "bg-red-50 border-red-200 text-red-600" : "bg-brand-50 border-brand-500/30"}`}>
            {qty > selected.stockQuantity ? (
              <>Không đủ tồn kho: chỉ còn {selected.stockQuantity} phần.</>
            ) : (
              <><b>{selected.name}</b>: {selected.stockQuantity} → <b className="text-red-600">{selected.stockQuantity - qty}</b> phần</>
            )}
          </div>
        )}

        <button className={`w-full text-white py-2.5 rounded-xl font-medium ${mode === "in" ? "bg-brand-600 hover:bg-brand-700" : "bg-red-500 hover:bg-red-600"}`}>
          {mode === "in" ? "Xác nhận nhập hàng" : "Xác nhận trừ kho"}
        </button>
      </form>

      {/* Tồn kho */}
      <section>
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          <h3 className="font-semibold text-lg">Tồn kho hiện tại</h3>
          <div className="flex flex-wrap items-center gap-2">
            {filters.map((f) => (
              <button key={f.key} onClick={() => setFilter(f.key)} className={`px-3 py-1 rounded-full text-sm ${filter === f.key ? "bg-brand-600 text-white" : "bg-white border"}`}>
                {f.label} ({f.count})
              </button>
            ))}
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm món..." className="border rounded-full px-4 py-1 text-sm w-36" />
          </div>
        </div>

        <div className="space-y-2">
          {visible.map((item) => {
            const st = statusOf(item.stockQuantity);
            const i = info(item.id);
            const pct = Math.min(100, (item.stockQuantity / maxStock) * 100);
            const expDays = i.expiryDate && item.stockQuantity > 0 ? daysUntil(i.expiryDate) : null;
            const margin = i.lastUnitCost != null ? item.price - i.lastUnitCost : null;
            const daysTone = i.daysLeft == null ? "text-gray-400" : i.daysLeft <= 2 ? "text-red-600 font-medium" : i.daysLeft <= 5 ? "text-amber-600" : "text-gray-500";
            return (
              <div key={item.id} className="bg-white border rounded-2xl p-3 flex items-center gap-3 shadow-sm">
                <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0">
                  <FoodImage src={item.imageUrl} alt={item.name} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-medium truncate">{item.name}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${st.cls}`}>{st.label}</span>
                    {expDays !== null && expDays <= 3 && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-red-50 text-red-600">
                        {expDays < 0 ? "Đã hết hạn" : `HSD còn ${expDays} ngày`}
                      </span>
                    )}
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full mt-2 overflow-hidden">
                    <div className={`h-full rounded-full ${st.bar}`} style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-xs mt-1.5 text-gray-500">
                    Bán 7 ngày: <b>{i.sold7 ?? 0}</b> ·{" "}
                    <span className={daysTone}>{i.daysLeft == null ? "chưa có đơn để ước tính" : `đủ bán ~${i.daysLeft} ngày`}</span>
                    {i.lastInAt && <> · Nhập gần nhất: {i.lastInQty} phần ({fmtDate(i.lastInAt)})</>}
                    {margin !== null && (
                      <> · Lãi gộp <span className={margin < 0 ? "text-red-600" : "text-green-600"}>{money(margin)}/phần</span></>
                    )}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-lg font-bold">{item.stockQuantity}</p>
                  <p className="text-xs text-gray-400">phần</p>
                </div>
                <button onClick={() => quickRestock(item)} className="text-sm px-3 py-1.5 rounded-lg border border-brand-500 text-brand-600 hover:bg-brand-50 shrink-0">
                  Nhập thêm
                </button>
              </div>
            );
          })}
          {visible.length === 0 && <p className="text-center text-gray-400 py-6">Không có món phù hợp</p>}
        </div>
      </section>

      {/* Lịch sử */}
      <section>
        <h3 className="font-semibold text-lg mb-3">Lịch sử nhập / điều chỉnh kho</h3>
        <div className="space-y-2">
          {shownHistory.map((h) => {
            const isAdjust = h.type === "adjust";
            return (
              <div key={h.id} className="bg-white border rounded-2xl p-3 flex items-center gap-3 shadow-sm">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold shrink-0 ${isAdjust ? "bg-red-50 text-red-600" : "bg-green-50 text-green-600"}`}>
                  {isAdjust ? "−" : "+"}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{h.menuItem.name}</p>
                  <p className="text-xs text-gray-400">
                    {new Date(h.createdAt).toLocaleString("vi-VN")}
                    {h.supplier && ` · NCC: ${h.supplier}`}
                    {h.unitCost != null && ` · giá ${money(h.unitCost)}/phần`}
                    {h.expiryDate && ` · HSD ${fmtDate(h.expiryDate)}`}
                    {h.note && ` · ${h.note}`}
                  </p>
                </div>
                <span className={`text-sm font-semibold shrink-0 ${isAdjust ? "text-red-600" : "text-green-600"}`}>
                  {h.quantity > 0 ? `+${h.quantity}` : h.quantity} phần
                </span>
              </div>
            );
          })}
          {history.length === 0 && <p className="text-center text-gray-400 py-6">Chưa có lịch sử</p>}
        </div>
        {history.length > 6 && (
          <button onClick={() => setShowAllHistory(!showAllHistory)} className="mt-3 w-full text-sm text-brand-600 hover:underline">
            {showAllHistory ? "Thu gọn" : `Xem thêm ${history.length - 6} phiếu`}
          </button>
        )}
      </section>
    </div>
  );
}
