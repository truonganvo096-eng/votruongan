import { Link, Outlet, useLocation } from "react-router-dom";

export default function AdminDashboard() {
  const location = useLocation();
  const tabs = [
    { path: "/admin", label: "Thực đơn" },
    { path: "/admin/stock", label: "Nhập hàng" },
    { path: "/admin/orders", label: "Đơn hàng" },
    { path: "/admin/database", label: "Cơ sở dữ liệu" },
    { path: "/admin/erd", label: "ERD" },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold mb-4">Trang quản trị</h1>
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {tabs.map((t) => (
          <Link
            key={t.path}
            to={t.path}
            className={`shrink-0 px-4 py-1.5 rounded-full text-sm ${
              location.pathname === t.path ? "bg-brand-600 text-white" : "bg-white border"
            }`}
          >
            {t.label}
          </Link>
        ))}
      </div>
      <Outlet />
    </div>
  );
}
