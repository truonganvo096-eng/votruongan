import FoodImage from "../components/FoodImage";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import client from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import RecommendationSection from "../components/RecommendationSection";

export default function MenuItemDetail() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const { user } = useAuth();
  const { addToCart } = useCart();

  useEffect(() => {
    window.scrollTo(0, 0); // chuyển sang món khác thì cuộn lên đầu trang
    setQuantity(1); // và đặt lại số lượng về 1
    client.get(`/menu/${id}`).then((res) => setItem(res.data.data));
    // Ghi log hành vi "view" ngay khi khách xem chi tiết món
    client.post("/behavior", { userId: user?.id, menuItemId: id, actionType: "view" });
  }, [id]);

  if (!item) return <div className="max-w-3xl mx-auto px-4 py-10">Đang tải...</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="bg-white border rounded-xl p-5">
        <div className="h-72 bg-gray-100 rounded-lg mb-4 flex items-center justify-center text-6xl overflow-hidden">
          {item.imageUrl ? (
              <FoodImage src={item.imageUrl} alt={item.name} />
          ) : (
            "🍽️"
          )}
        </div>
        <h1 className="text-2xl font-bold">{item.name}</h1>
        <p className="text-gray-500 mt-1">{item.description}</p>
        <p className="text-brand-600 text-xl font-semibold mt-3">
          {item.price.toLocaleString()}đ
        </p>
        <p className={`text-sm mt-1 ${item.stockQuantity === 0 ? "text-red-500 font-medium" : "text-gray-400"}`}>
          {item.stockQuantity === 0 ? "Hết hàng" : `Còn ${item.stockQuantity} phần`}
        </p>

        <div className="flex items-center gap-3 mt-4">
          <div className="flex items-center border rounded-lg">
            <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="px-3 py-1.5">-</button>
            <span className="px-4">{quantity}</span>
            <button onClick={() => setQuantity((q) => q + 1)} className="px-3 py-1.5">+</button>
          </div>
          <button
            onClick={() => {
              addToCart(item, quantity);
              client.post("/behavior", { userId: user?.id, menuItemId: item.id, actionType: "add_to_cart" });
            }}
            disabled={item.stockQuantity === 0}
            className="flex-1 bg-brand-600 text-white py-2 rounded-lg hover:bg-brand-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            {item.stockQuantity === 0 ? "Hết hàng" : "Thêm vào giỏ hàng"}
          </button>
        </div>
      </div>

      {/* Module gợi ý — điểm nhấn AI của đồ án */}
      <RecommendationSection
        type="frequently-bought"
        menuItemId={item.id}
        title="🔥 Khách hàng thường gọi kèm"
      />
      <RecommendationSection
        type="similar"
        menuItemId={item.id}
        title="🍴 Món tương tự"
      />
    </div>
  );
}