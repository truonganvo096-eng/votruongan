import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { register } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      await register(name, email, password);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Đăng ký thất bại");
    }
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-16">
      <h1 className="text-xl font-bold mb-6 text-center">Đăng ký</h1>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input required placeholder="Họ tên" value={name} onChange={(e) => setName(e.target.value)} className="w-full border rounded-lg px-4 py-2" />
        <input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border rounded-lg px-4 py-2" />
        <input type="password" required placeholder="Mật khẩu" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full border rounded-lg px-4 py-2" />
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <button className="w-full bg-brand-600 text-white py-2.5 rounded-lg hover:bg-brand-700">Đăng ký</button>
      </form>
      <p className="text-center text-sm text-gray-500 mt-4">
        Đã có tài khoản? <Link to="/login" className="text-brand-600">Đăng nhập</Link>
      </p>
    </div>
  );
}
