import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import MenuItemDetail from "./pages/MenuItemDetail";
import Cart from "./pages/Cart";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Orders from "./pages/Orders";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminMenu from "./pages/admin/AdminMenu";
import AdminStock from "./pages/admin/AdminStock";
import AdminOrders from "./pages/admin/AdminOrders";
import { useAuth } from "./context/AuthContext";
import AdminDatabase from "./pages/admin/AdminDatabase";
import AdminErd from "./pages/admin/AdminErd";

function RequireAuth({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" />;
}

function RequireAdmin({ children }) {
  const { user } = useAuth();
  return user?.role === "admin" ? children : <Navigate to="/" />;
}

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/menu/:id" element={<MenuItemDetail />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/orders" element={<RequireAuth><Orders /></RequireAuth>} />
        <Route
          path="/admin"
          element={<RequireAdmin><AdminDashboard /></RequireAdmin>}
        >
          <Route index element={<AdminMenu />} />
          <Route path="stock" element={<AdminStock />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="database" element={<AdminDatabase />} />
          <Route path="erd" element={<AdminErd />} />
        </Route>
      </Routes>
    </div>
  );
}
