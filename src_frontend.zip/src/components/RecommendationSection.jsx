import { useEffect, useState } from "react";
import client from "../api/client";
import { useCart } from "../context/CartContext";
import { Link } from "react-router-dom";
/**
 * Khung hiển thị gợi ý món ăn — dùng chung cho nhiều nơi (trang chi tiết, trang chủ)
 * type: "frequently-bought" | "similar" | "for-you"
 */
export default function RecommendationSection({ type, menuItemId, userId, title }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();

  useEffect(() => {
    let url = "";
    if (type === "frequently-bought") url = `/recommendations/frequently-bought/${menuItemId}`;
    if (type === "similar") url = `/recommendations/similar/${menuItemId}`;
    if (type === "for-you") {
      // Chưa đăng nhập thì không gọi API, ẩn mục này
      if (!userId) {
        setItems([]);
        setLoading(false);
        return;
      }
      url = `/recommendations/for-you?userId=${userId}`;
    }
    if (!url) return;

    setLoading(true);
    client
      .get(url)
      .then((res) => setItems(res.data.data || []))
      .catch((err) => {
        console.error("recommendation error:", err);
        setItems([]);
      })
      .finally(() => setLoading(false));
  }, [type, menuItemId, userId]);

  if (loading) return null;
  if (!items || items.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="font-semibold text-lg mb-3">{title}</h3>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {items.map((item) => (
          <div
            key={item.id}
            className="border rounded-xl p-3 min-w-[160px] bg-white flex-shrink-0"
          >
            <Link to={`/menu/${item.id}`} className="block">
              <div className="h-20 bg-gray-100 rounded-lg mb-2 flex items-center justify-center text-2xl overflow-hidden">
                {item.imageUrl ? (
                  <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                ) : (
                  "🍽️"
                )}
              </div>
              <p className="font-medium text-sm">{item.name}</p>
              <p className="text-brand-600 text-sm font-semibold">
                {Number(item.price).toLocaleString()}đ
              </p>
              {item.confidence_percent !== undefined && (
                <p className="text-xs text-gray-400 mt-1">
                  {item.confidence_percent}% khách chọn kèm
                </p>
              )}
            </Link>
            <button
              onClick={() => addToCart(item, 1)}
              className="mt-2 w-full text-xs bg-brand-50 text-brand-700 py-1.5 rounded-lg hover:bg-brand-100"
            >
              + Thêm vào giỏ
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}