import { useRef, useState } from "react";

/**
 * Ảnh món ăn hiển thị đẹp với mọi loại ảnh.
 * - Lấp đầy khung cha (w-full h-full), KHÔNG đổi kích thước/bố cục của card.
 * - Ảnh có tỉ lệ gần giống khung  -> cắt vừa khung (object-cover) như hiện tại.
 * - Ảnh lệch tỉ lệ (vd ly nước nền trắng) -> hiện TRỌN ảnh (object-contain),
 *   phía sau là chính ảnh đó làm mờ nên không bị khoảng trắng xấu.
 * - Link ảnh lỗi / chưa có ảnh -> hiện icon dự phòng thay vì ô trống.
 *
 * Cách dùng: thay thẻ <img ... /> cũ bằng
 *   <FoodImage src={item.imageUrl} alt={item.name} />
 * Thẻ cha bên ngoài cần có chiều cao cố định (h-24, h-48, aspect-[4/3]...) như bạn đang dùng.
 */
export default function FoodImage({ src, alt = "", fallback = "🍽️" }) {
  const boxRef = useRef(null);
  const [fit, setFit] = useState("cover");
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-100 text-3xl select-none">
        {fallback}
      </div>
    );
  }

  function handleLoad(e) {
    const { naturalWidth: iw, naturalHeight: ih } = e.currentTarget;
    const box = boxRef.current;
    if (!iw || !ih || !box || !box.clientHeight) return;
    const imgRatio = iw / ih;
    const boxRatio = box.clientWidth / box.clientHeight;
    // Chênh lệch tỉ lệ quá 35% thì cắt sẽ mất nhiều -> chuyển sang hiện trọn ảnh
    const diff = Math.abs(imgRatio - boxRatio) / boxRatio;
    setFit(diff > 0.35 ? "contain" : "cover");
  }

  return (
    <div ref={boxRef} className="relative w-full h-full overflow-hidden bg-gray-100">
      {fit === "contain" && (
        <img
          src={src}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 w-full h-full object-cover blur-xl scale-110 opacity-60"
        />
      )}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={handleLoad}
        onError={() => setFailed(true)}
        className={`relative w-full h-full ${fit === "contain" ? "object-contain" : "object-cover"}`}
      />
    </div>
  );
}
