// Sơ đồ ERD 7 bảng, vẽ bằng SVG thuần (không cần thư viện ngoài).
const COLORS = {
  blue: { fill: "#E6F1FB", stroke: "#378ADD", text: "#0C447C" },
  teal: { fill: "#E1F5EE", stroke: "#1D9E75", text: "#085041" },
  coral: { fill: "#FAECE7", stroke: "#D85A30", text: "#712B13" },
};

const W = 120; // chiều rộng mỗi bảng

const ENTITIES = [
  { name: "User", x: 40, y: 30, h: 116, c: "blue", fields: ["id  PK", "name", "email", "role"] },
  { name: "Order", x: 200, y: 30, h: 116, c: "blue", fields: ["id  PK", "userId  FK", "status", "total"] },
  { name: "OrderItem", x: 360, y: 30, h: 116, c: "blue", fields: ["id  PK", "orderId  FK", "menuItemId  FK", "quantity"] },
  { name: "BehaviorLog", x: 40, y: 220, h: 116, c: "coral", fields: ["id  PK", "userId  FK", "menuItemId  FK", "actionType"] },
  { name: "MenuItem", x: 360, y: 220, h: 134, c: "teal", fields: ["id  PK", "categoryId  FK", "name", "price", "stockQuantity"] },
  { name: "Category", x: 520, y: 220, h: 62, c: "teal", fields: ["id  PK", "name"] },
  { name: "StockEntry", x: 360, y: 400, h: 98, c: "teal", fields: ["id  PK", "menuItemId  FK", "quantity"] },
];

// [x1, y1, x2, y2]
const EDGES = [
  [160, 88, 200, 88],
  [320, 88, 360, 88],
  [100, 146, 100, 220],
  [420, 146, 420, 220],
  [160, 269, 360, 269],
  [480, 250, 520, 250],
  [420, 354, 420, 400],
];

// [x, y, nội dung, canh lề]
const LABELS = [
  [168, 80, "1", "middle"], [192, 80, "n", "middle"],
  [328, 80, "1", "middle"], [352, 80, "n", "middle"],
  [108, 162, "1", "start"], [108, 212, "n", "start"],
  [428, 162, "n", "start"], [428, 212, "1", "start"],
  [172, 261, "n", "middle"], [348, 261, "1", "middle"],
  [488, 242, "n", "middle"], [512, 242, "1", "middle"],
  [428, 372, "1", "start"], [428, 394, "n", "start"],
];

export default function ErdDiagram() {
  return (
    <div className="bg-white border rounded-xl p-4">
      <svg viewBox="0 0 680 520" className="w-full max-w-3xl mx-auto" role="img" aria-label="Sơ đồ ERD của ứng dụng đặt món ăn">
        {EDGES.map(([x1, y1, x2, y2], i) => (
          <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#888" strokeWidth="1.2" />
        ))}

        {LABELS.map(([x, y, t, anchor], i) => (
          <text key={i} x={x} y={y} textAnchor={anchor} fontSize="12" fill="#555">{t}</text>
        ))}

        {ENTITIES.map((e) => {
          const col = COLORS[e.c];
          return (
            <g key={e.name}>
              <rect x={e.x} y={e.y} width={W} height={e.h} rx="8" fill={col.fill} stroke={col.stroke} strokeWidth="1" />
              <text x={e.x + W / 2} y={e.y + 18} textAnchor="middle" fontSize="14" fontWeight="600" fill={col.text}>
                {e.name}
              </text>
              <line x1={e.x} y1={e.y + 26} x2={e.x + W} y2={e.y + 26} stroke={col.stroke} strokeWidth="0.8" />
              {e.fields.map((f, i) => (
                <text key={f} x={e.x + 10} y={e.y + 44 + i * 18} fontSize="12" fill={col.text}>{f}</text>
              ))}
            </g>
          );
        })}

        <text x="40" y="420" fontSize="14" fontWeight="600" fill="#333">Chú thích</text>
        <text x="40" y="440" fontSize="12" fill="#555">PK: khóa chính</text>
        <text x="40" y="458" fontSize="12" fill="#555">FK: khóa ngoại</text>
        <text x="40" y="476" fontSize="12" fill="#555">1 — n: quan hệ một - nhiều</text>
        <text x="40" y="494" fontSize="12" fill="#555">Màu cam: bảng dữ liệu cho AI</text>
      </svg>
    </div>
  );
}
