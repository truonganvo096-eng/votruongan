import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const navigate = useNavigate();

  return (
    <nav className="bg-white border-b sticky top-0 z-10">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-xl font-bold text-brand-600">
          🍜 Gọi Món Ngon
        </Link>

        <div className="flex items-center gap-4 text-sm">
          <Link to="/" className="hover:text-brand-600">Thực đơn</Link>

          {user && (
            <Link to="/orders" className="hover:text-brand-600">Đơn của tôi</Link>
          )}

          {user?.role === "admin" && (
            <Link to="/admin" className="hover:text-brand-600 font-medium">Quản trị</Link>
          )}

          <Link to="/cart" className="relative hover:text-brand-600">
            Giỏ hàng
            {count > 0 && (
              <span className="absolute -top-2 -right-3 bg-brand-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {count}
              </span>
            )}
          </Link>

          {user ? (
            <div className="flex items-center gap-2">
              <span className="text-gray-500">Xin chào, {user.name}</span>
              <button
                onClick={() => { logout(); navigate("/"); }}
                className="text-red-500 hover:underline"
              >
                Đăng xuất
              </button>
            </div>
          ) : (
            <Link to="/login" className="bg-brand-600 text-white px-3 py-1.5 rounded-lg hover:bg-brand-700">
              Đăng nhập
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
