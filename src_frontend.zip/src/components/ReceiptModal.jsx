import { printReceipt } from "../utils/printReceipt";

// Hiện hóa đơn ngay trên trang (không mở cửa sổ mới) — dùng để xem/test
// khi chưa có máy in thật. Có nút "In" riêng cho lúc nào có máy in thì dùng.
export default function ReceiptModal({ order, onClose }) {
  if (!order) return null;

  const orderCode = order.id.slice(0, 8).toUpperCase();
  const dateStr = new Date(order.createdAt).toLocaleString("vi-VN");

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-xl shadow-lg w-full max-w-xs p-5 font-mono text-sm">
        <h2 className="text-center font-bold text-lg mb-0.5">🍜 Gọi Món Ngon</h2>
        <p className="text-center text-gray-500 text-xs mb-3">Hóa đơn bán hàng</p>
        <hr className="border-dashed border-gray-300 mb-2" />

        <div className="flex justify-between text-xs">
          <span>Mã đơn</span>
          <span>#{orderCode}</span>
        </div>
        <div className="flex justify-between text-xs mb-2">
          <span>Thời gian</span>
          <span>{dateStr}</span>
        </div>
        <hr className="border-dashed border-gray-300 mb-2" />

        <table className="w-full text-xs mb-2">
          <thead>
            <tr className="border-b border-gray-300">
              <th className="text-left py-1">Món</th>
              <th className="text-center py-1">SL</th>
              <th className="text-right py-1">T.Tiền</th>
            </tr>
          </thead>
          <tbody>
            {order.items.map((i) => (
              <tr key={i.id}>
                <td className="py-0.5">{i.menuItem.name}</td>
                <td className="text-center py-0.5">{i.quantity}</td>
                <td className="text-right py-0.5">{i.subtotal.toLocaleString()}đ</td>
              </tr>
            ))}
          </tbody>
        </table>
        <hr className="border-dashed border-gray-300 mb-2" />

        <div className="flex justify-between font-bold text-base mb-3">
          <span>Tổng cộng</span>
          <span>{order.total.toLocaleString()}đ</span>
        </div>
        <p className="text-center text-gray-500 text-xs mb-4">Cảm ơn quý khách đã đặt món!</p>

        <div className="flex gap-2">
          <button
            onClick={() => printReceipt(order)}
            className="flex-1 border border-brand-600 text-brand-600 rounded-lg py-2 text-sm hover:bg-brand-50"
          >
            🖨️ In (nếu có máy in)
          </button>
          <button
            onClick={onClose}
            className="flex-1 bg-brand-600 text-white rounded-lg py-2 text-sm hover:bg-brand-700"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}
