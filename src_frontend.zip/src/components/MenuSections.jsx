import { Link } from "react-router-dom";
import FoodImage from "./FoodImage";

/**
 * Hiển thị danh sách món, tách 2 khu: MÓN ĂN (ảnh ngang) và ĐỒ UỐNG (ảnh đứng).
 *
 * Props:
 *  - items:   danh sách món (mỗi món có item.category.name, do API /menu đã include)
 *  - grouped: true  -> chia 2 khu có tiêu đề (dùng khi đang ở mục "Tất cả")
 *             false -> chỉ 1 lưới, kiểu card tự chọn theo danh mục của món
 *  - onAdd:   hàm thêm vào giỏ, chính là handleAdd(item) đang có trong Home.jsx
 *
 * Kiểu card quyết định theo TÊN DANH MỤC: tên có chữ "uống" (vd "Đồ uống") -> ảnh đứng.
 * Lưu ý: KHÔNG dùng chữ "nước" vì "Món nước" (phở, bún...) là món ăn.
 */

function isDrink(item) {
  const name = (item.category?.name || "").toLowerCase();
  return name.includes("uống");
}

// Tỉ lệ khung ảnh: món ăn = ngang như hiện tại, đồ uống = đứng cho vừa ly
const WIDE_RATIO = "11 / 5";
const TALL_RATIO = "3 / 4";

function MenuCard({ item, tall, onAdd }) {
  const outOfStock = item.stockQuantity === 0;

  return (
    <div className="bg-white border rounded-2xl shadow-sm">
      <div className="relative">
        <Link to={`/menu/${item.id}`} className="block">
          <div
            className="overflow-hidden rounded-t-2xl bg-gray-100"
            style={{ aspectRatio: tall ? TALL_RATIO : WIDE_RATIO }}
          >
            <FoodImage src={item.imageUrl} alt={item.name} />
          </div>
        </Link>

        <button
          onClick={() => onAdd(item)}
          disabled={outOfStock}
          aria-label={`Thêm ${item.name} vào giỏ`}
          className="absolute right-3 bottom-0 translate-y-1/2 w-11 h-11 rounded-full bg-brand-600 text-white text-2xl leading-none shadow-md hover:bg-brand-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center"
        >
          +
        </button>
      </div>

      <Link to={`/menu/${item.id}`} className="block px-3 pt-4 pb-3">
        <p className="font-medium text-sm">{item.name}</p>
        <p className="text-brand-600 font-semibold mt-2">{item.price.toLocaleString()}đ</p>
        {outOfStock && <p className="text-red-500 text-xs font-medium mt-1">Hết hàng</p>}
      </Link>
    </div>
  );
}

function FoodGrid({ items, onAdd }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
      {items.map((item) => (
        <MenuCard key={item.id} item={item} tall={false} onAdd={onAdd} />
      ))}
    </div>
  );
}

function DrinkGrid({ items, onAdd }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
      {items.map((item) => (
        <MenuCard key={item.id} item={item} tall={true} onAdd={onAdd} />
      ))}
    </div>
  );
}

export default function MenuSections({ items, grouped, onAdd }) {
  if (items.length === 0) {
    return <p className="text-center text-gray-400 py-10">Không tìm thấy món nào</p>;
  }

  const foods = items.filter((i) => !isDrink(i));
  const drinks = items.filter((i) => isDrink(i));

  // Đang lọc theo 1 danh mục: chỉ 1 lưới, kiểu card theo danh mục đó
  if (!grouped) {
    return isDrink(items[0]) ? (
      <DrinkGrid items={items} onAdd={onAdd} />
    ) : (
      <FoodGrid items={items} onAdd={onAdd} />
    );
  }

  // Mục "Tất cả": chia 2 khu, khu nào không có món thì ẩn luôn tiêu đề
  return (
    <div className="space-y-8">
      {foods.length > 0 && (
        <section>
          <h2 className="font-semibold text-lg mb-3">🍜 Món ăn</h2>
          <FoodGrid items={foods} onAdd={onAdd} />
        </section>
      )}
      {drinks.length > 0 && (
        <section>
          <h2 className="font-semibold text-lg mb-3">🥤 Đồ uống</h2>
          <DrinkGrid items={drinks} onAdd={onAdd} />
        </section>
      )}
    </div>
  );
}
