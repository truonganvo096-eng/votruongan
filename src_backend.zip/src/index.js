require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const menuRoutes = require("./routes/menu");
const categoryRoutes = require("./routes/categories");
const orderRoutes = require("./routes/orders");
const behaviorRoutes = require("./routes/behavior");
const recommendationRoutes = require("./routes/recommendations");
const stockRoutes = require("./routes/stock");
const dbViewerRoutes = require("./routes/dbviewer");
// SQLite trả COUNT(...) kiểu BigInt, JSON không chuyển được -> đổi sang số
BigInt.prototype.toJSON = function () { return Number(this); };

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => res.json({ ok: true, message: "Food Ordering API đang chạy" }));

app.use("/api/auth", authRoutes);
app.use("/api/menu", menuRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/behavior", behaviorRoutes);
app.use("/api/recommendations", recommendationRoutes);
app.use("/api/stock", stockRoutes);
app.use("/api/db", dbViewerRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend chạy tại http://localhost:${PORT}`));
