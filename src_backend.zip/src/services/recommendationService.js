const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

/**
 * "MÓN HAY MUA CÙNG NHAU" — Association Rule Mining (đơn giản hóa)
 *
 * Ý tưởng: với món A, tìm các đơn hàng có chứa món A, đếm những món khác
 * xuất hiện cùng, rồi tính tỷ lệ % (Confidence) = số đơn có cả A&B / số đơn có A
 *
 * Lưu ý: query dưới đây viết cho SQLite (mặc định của project để chạy nhanh
 * không cần cài server DB). Nếu đổi sang PostgreSQL, đổi CAST(x AS REAL)
 * thành x::numeric là chạy được ngay, cú pháp còn lại không đổi.
 */
async function getFrequentlyBoughtTogether(menuItemId, limit = 3) {
  const result = await prisma.$queryRawUnsafe(
    `
    WITH orders_with_item AS (
      SELECT DISTINCT oi."orderId" as orderId
      FROM OrderItem oi
      WHERE oi."menuItemId" = ?
    ),
    co_occurrence AS (
      SELECT
        oi."menuItemId" as menuItemId,
        COUNT(DISTINCT oi."orderId") AS co_count
      FROM OrderItem oi
      INNER JOIN orders_with_item owi ON oi."orderId" = owi.orderId
      WHERE oi."menuItemId" != ?
      GROUP BY oi."menuItemId"
    ),
    total_orders AS (
      SELECT COUNT(*) AS total FROM orders_with_item
    )
    SELECT
      mi.id as id,
      mi.name as name,
      mi.price as price,
      mi."imageUrl" as imageUrl,
      co.co_count as co_count,
      ROUND((CAST(co.co_count AS REAL) / CAST(t.total AS REAL)) * 100, 1) AS confidence_percent
    FROM co_occurrence co
    INNER JOIN MenuItem mi ON mi.id = co.menuItemId
    CROSS JOIN total_orders t
    WHERE mi.available = 1
    ORDER BY co.co_count DESC
    LIMIT ?;
    `,
    menuItemId,
    menuItemId,
    limit
  );

  return result;
}

/**
 * "MÓN TƯƠNG TỰ" — Content-based filtering
 * Lọc theo cùng danh mục + khoảng giá gần tương đương (+-30%)
 */
async function getSimilarItems(menuItemId, limit = 4) {
  const currentItem = await prisma.menuItem.findUnique({ where: { id: menuItemId } });
  if (!currentItem) return [];

  const sameCategory = await prisma.menuItem.findMany({
    where: {
      categoryId: currentItem.categoryId,
      id: { not: menuItemId },
      available: true,
    },
  });

  // Món có giá gần nhất xếp trước; không loại món nào chỉ vì lệch giá
  return sameCategory
    .sort((a, b) => Math.abs(a.price - currentItem.price) - Math.abs(b.price - currentItem.price))
    .slice(0, limit);
}

/**
 * "GỢI Ý CHO BẠN" (trang chủ) — cá nhân hóa dựa trên lịch sử người dùng
 * - Tính điểm từng danh mục theo hành vi (view/add_to_cart/purchase...)
 * - Loại các món user đã tương tác gần đây để gợi ý luôn mới
 * - Trộn nhiều danh mục: lấy món từ top danh mục, xáo trộn mỗi lần tải
 * - Chưa có lịch sử -> best seller toàn hệ thống
 */
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function getForYouRecommendations(userId, limit = 6) {
  const inStock = { available: true, stockQuantity: { gt: 0 } };
  let result = [];

  if (userId) {
    // 1. Điểm từng món theo hành vi + đơn hàng đã đặt
    const scored = await prisma.$queryRawUnsafe(
      `
      SELECT s.menuItemId as id, SUM(s.w) as score
      FROM (
        SELECT "menuItemId" as menuItemId,
               CASE "actionType" WHEN 'purchase' THEN 3 WHEN 'add_to_cart' THEN 2 ELSE 1 END as w
        FROM BehaviorLog
        WHERE "userId" = ?
        UNION ALL
        SELECT oi."menuItemId" as menuItemId, 3 * oi.quantity as w
        FROM OrderItem oi
        INNER JOIN "Order" o ON o.id = oi."orderId"
        WHERE o."userId" = ?
      ) s
      GROUP BY s.menuItemId
      ORDER BY score DESC
      LIMIT 10;
      `,
      userId,
      userId
    );
    const rankedIds = scored.map((r) => r.id);

    if (rankedIds.length > 0) {
      // 2. Món yêu thích nhất (còn hàng), giữ đúng thứ tự điểm
      const favRows = await prisma.menuItem.findMany({
        where: { ...inStock, id: { in: rankedIds } },
      });
      const favorites = rankedIds
        .map((id) => favRows.find((m) => m.id === id))
        .filter(Boolean)
        .slice(0, 3);
      result = [...favorites];

      // 3. Món chưa thử, cùng danh mục với các món yêu thích
      const allRows = await prisma.menuItem.findMany({
        where: { id: { in: rankedIds } },
        select: { categoryId: true },
      });
      const categoryIds = [...new Set(allRows.map((m) => m.categoryId))];

      const similar = await prisma.menuItem.findMany({
        where: {
          ...inStock,
          categoryId: { in: categoryIds },
          id: { notIn: rankedIds },
        },
      });
      result = result.concat(shuffle(similar).slice(0, limit - result.length));
    }

    // 4. Chưa đủ -> bù món bất kỳ còn hàng chưa có trong danh sách
    if (result.length > 0 && result.length < limit) {
      const have = result.map((r) => r.id);
      const more = await prisma.menuItem.findMany({
        where: { ...inStock, id: { notIn: have } },
      });
      result = result.concat(shuffle(more).slice(0, limit - result.length));
    }

    if (result.length > 0) return result;
  }

  // Fallback: user chưa có lịch sử -> best seller (chỉ món còn hàng)
  const best = await prisma.$queryRawUnsafe(
    `
    SELECT oi."menuItemId" as id
    FROM OrderItem oi
    INNER JOIN MenuItem mi ON mi.id = oi."menuItemId"
    WHERE mi.available = 1 AND mi."stockQuantity" > 0
    GROUP BY oi."menuItemId"
    ORDER BY SUM(oi.quantity) DESC
    LIMIT ?;
    `,
    limit
  );
  const ids = best.map((b) => b.id);
  const rows = await prisma.menuItem.findMany({ where: { id: { in: ids } } });
  return ids.map((id) => rows.find((m) => m.id === id)).filter(Boolean);
}

module.exports = { getFrequentlyBoughtTogether, getSimilarItems, getForYouRecommendations };
