const express = require("express");
const { PrismaClient } = require("@prisma/client");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();
const prisma = new PrismaClient();

// Chỉ admin mới xem được dữ liệu thô của database
router.use(requireAuth, requireAdmin);

// Mỗi bảng khai báo: cách đếm và cách lấy dữ liệu.
// Các bảng có quan hệ sẽ được "nối" để hiện TÊN (món ăn, khách hàng...) thay vì chỉ có mã UUID.
const TABLES = {
  User: {
    count: () => prisma.user.count(),
    rows: async (take) => {
      const data = await prisma.user.findMany({ take, orderBy: { createdAt: "desc" } });
      // Không bao giờ trả mật khẩu ra ngoài, kể cả bản đã mã hóa
      return data.map(({ password, ...rest }) => rest);
    },
  },
  Category: {
    count: () => prisma.category.count(),
    rows: (take) => prisma.category.findMany({ take }),
  },
  MenuItem: {
    count: () => prisma.menuItem.count(),
    rows: async (take) => {
      const data = await prisma.menuItem.findMany({ take, include: { category: true } });
      return data.map(({ category, ...rest }) => ({ ...rest, categoryName: category?.name }));
    },
  },
  Order: {
    count: () => prisma.order.count(),
    rows: async (take) => {
      const data = await prisma.order.findMany({ take, include: { user: true }, orderBy: { createdAt: "desc" } });
      return data.map(({ user, ...rest }) => ({ ...rest, userName: user?.name }));
    },
  },
  OrderItem: {
    count: () => prisma.orderItem.count(),
    rows: async (take) => {
      const data = await prisma.orderItem.findMany({ take, include: { menuItem: true } });
      return data.map(({ menuItem, ...rest }) => ({ ...rest, menuItemName: menuItem?.name }));
    },
  },
  BehaviorLog: {
    count: () => prisma.behaviorLog.count(),
    rows: async (take) => {
      const data = await prisma.behaviorLog.findMany({
        take,
        include: { user: true, menuItem: true },
        orderBy: { createdAt: "desc" },
      });
      return data.map(({ user, menuItem, ...rest }) => ({
        ...rest,
        userName: user?.name || "(ẩn danh)",
        menuItemName: menuItem?.name,
      }));
    },
  },
  StockEntry: {
    count: () => prisma.stockEntry.count(),
    rows: async (take) => {
      const data = await prisma.stockEntry.findMany({
        take,
        include: { menuItem: true },
        orderBy: { createdAt: "desc" },
      });
      return data.map(({ menuItem, ...rest }) => ({ ...rest, menuItemName: menuItem?.name }));
    },
  },
};

// GET /api/db/tables — danh sách bảng kèm số dòng
router.get("/tables", async (req, res) => {
  try {
    const names = Object.keys(TABLES);
    const counts = await Promise.all(names.map((n) => TABLES[n].count()));
    res.json({ success: true, data: names.map((name, i) => ({ name, count: counts[i] })) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi đọc danh sách bảng" });
  }
});

// GET /api/db/tables/:name?limit=200 — dữ liệu của 1 bảng
router.get("/tables/:name", async (req, res) => {
  try {
    const table = TABLES[req.params.name];
    if (!table) return res.status(404).json({ success: false, message: "Không có bảng này" });

    const limit = Math.min(Number(req.query.limit) || 200, 500);
    const [rows, total] = await Promise.all([table.rows(limit), table.count()]);
    const columns = rows.length > 0 ? Object.keys(rows[0]) : [];
    res.json({ success: true, data: { columns, rows, total } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi đọc dữ liệu bảng" });
  }
});

module.exports = router;
