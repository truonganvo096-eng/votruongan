const express = require("express");
const { PrismaClient } = require("@prisma/client");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();
const prisma = new PrismaClient();

// Tạo link ảnh mã QR VietQR (động theo số tiền) cho một đơn hàng
function buildQrUrl(order) {
  const bankId = process.env.BANK_ID;
  const accountNo = process.env.BANK_ACCOUNT_NO;
  const accountName = process.env.BANK_ACCOUNT_NAME;
  if (!bankId || !accountNo) return null;

  const addInfo = `DH ${order.id.slice(0, 8).toUpperCase()}`;
  const params = new URLSearchParams({
    amount: String(Math.round(order.total)),
    addInfo,
  });
  if (accountName) params.set("accountName", accountName);

  return `https://img.vietqr.io/image/${bankId}-${accountNo}-compact2.png?${params.toString()}`;
}

class OrderError extends Error {}

// POST /api/orders — tạo đơn hàng từ giỏ hàng
// body: { items: [{ menuItemId, quantity }] }
router.post("/", requireAuth, async (req, res) => {
  try {
    const { items } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: "Giỏ hàng trống" });
    }

    // Kiểm tra số lượng hợp lệ và gộp các dòng trùng món
    const merged = new Map();
    for (const i of items) {
      const qty = Number(i.quantity);
      if (!i.menuItemId || !Number.isInteger(qty) || qty <= 0 || qty > 99) {
        return res.status(400).json({ success: false, message: "Số lượng món không hợp lệ" });
      }
      merged.set(i.menuItemId, (merged.get(i.menuItemId) || 0) + qty);
    }
    const lines = [...merged].map(([menuItemId, quantity]) => ({ menuItemId, quantity }));

    // Toàn bộ trong 1 transaction: lỗi giữa chừng thì không tạo đơn, không mất kho
    const order = await prisma.$transaction(async (tx) => {
      const ids = lines.map((l) => l.menuItemId);
      const menuItems = await tx.menuItem.findMany({ where: { id: { in: ids } } });

      let total = 0;
      const orderItemsData = [];
      for (const l of lines) {
        const m = menuItems.find((x) => x.id === l.menuItemId);
        if (!m) throw new OrderError("Món ăn không tồn tại");
        if (!m.available) throw new OrderError(`"${m.name}" hiện không bán`);

        // Chỉ trừ kho khi còn đủ hàng: hai khách đặt cùng lúc cũng không bán vượt tồn kho
        const r = await tx.menuItem.updateMany({
          where: { id: m.id, stockQuantity: { gte: l.quantity } },
          data: { stockQuantity: { decrement: l.quantity } },
        });
        if (r.count === 0) {
          throw new OrderError(`"${m.name}" chỉ còn ${m.stockQuantity} phần, không đủ số lượng bạn đặt`);
        }

        const subtotal = m.price * l.quantity;
        total += subtotal;
        orderItemsData.push({ menuItemId: l.menuItemId, quantity: l.quantity, subtotal });
      }

      // Món nào về 0 thì tự động đánh dấu hết hàng
      await tx.menuItem.updateMany({
        where: { id: { in: ids }, stockQuantity: 0 },
        data: { available: false },
      });

      const created = await tx.order.create({
        data: { userId: req.user.id, total, status: "pending", items: { create: orderItemsData } },
        include: { items: { include: { menuItem: true } } },
      });

      // Ghi log hành vi "purchase" cho từng món — dữ liệu nuôi module gợi ý
      await tx.behaviorLog.createMany({
        data: lines.map((l) => ({ userId: req.user.id, menuItemId: l.menuItemId, actionType: "purchase" })),
      });

      return created;
    });

    res.json({ success: true, data: { ...order, qrUrl: buildQrUrl(order) } });
  } catch (err) {
    if (err instanceof OrderError) {
      return res.status(400).json({ success: false, message: err.message });
    }
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi tạo đơn hàng" });
  }
});

// GET /api/orders — đơn hàng của chính người dùng đang đăng nhập
router.get("/", requireAuth, async (req, res) => {
  const orders = await prisma.order.findMany({
    where: { userId: req.user.id },
    include: { items: { include: { menuItem: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, data: orders });
});

// GET /api/orders/all — admin xem toàn bộ đơn hàng
router.get("/all", requireAuth, requireAdmin, async (req, res) => {
  const orders = await prisma.order.findMany({
    include: { items: { include: { menuItem: true } }, user: true },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, data: orders });
});

// GET /api/orders/:id — chi tiết 1 đơn của chính người dùng (kèm qrUrl để hiện lại QR thanh toán)
router.get("/:id", requireAuth, async (req, res) => {
  const order = await prisma.order.findUnique({
    where: { id: req.params.id },
    include: { items: { include: { menuItem: true } } },
  });
  if (!order || (order.userId !== req.user.id && req.user.role !== "admin")) {
    return res.status(404).json({ success: false, message: "Không tìm thấy đơn hàng" });
  }
  res.json({ success: true, data: { ...order, qrUrl: buildQrUrl(order) } });
});

// PUT /api/orders/:id/status — admin cập nhật trạng thái đơn
// Hủy đơn sẽ hoàn lại tồn kho; đơn đã hủy thì không đổi lại được nữa
const VALID_STATUS = ["pending", "confirmed", "preparing", "delivering", "completed", "cancelled"];

router.put("/:id/status", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    if (!VALID_STATUS.includes(status)) {
      return res.status(400).json({ success: false, message: "Trạng thái không hợp lệ" });
    }

    const current = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { items: true },
    });
    if (!current) return res.status(404).json({ success: false, message: "Không tìm thấy đơn hàng" });
    if (current.status === "cancelled" && status !== "cancelled") {
      return res.status(400).json({ success: false, message: "Đơn đã hủy, không thể đổi trạng thái" });
    }

    const order = await prisma.$transaction(async (tx) => {
      // Vừa chuyển sang "cancelled": cộng lại kho cho từng món
      if (status === "cancelled" && current.status !== "cancelled") {
        for (const it of current.items) {
          await tx.menuItem.update({
            where: { id: it.menuItemId },
            data: { stockQuantity: { increment: it.quantity }, available: true },
          });
        }
      }
      return tx.order.update({ where: { id: req.params.id }, data: { status } });
    });

    res.json({ success: true, data: order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi cập nhật trạng thái đơn" });
  }
});

module.exports = router;
