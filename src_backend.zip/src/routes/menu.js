const express = require("express");
const { PrismaClient } = require("@prisma/client");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();
const prisma = new PrismaClient();

// GET /api/menu?category=&search=
router.get("/", async (req, res) => {
  try {
    const { category, search, all } = req.query;
    const where = {
      ...(all === "1" ? {} : { available: true }),
      ...(category ? { categoryId: category } : {}),
      ...(search ? { name: { contains: search } } : {}),
    };
    const items = await prisma.menuItem.findMany({
      where,
      include: { category: true },
      orderBy: { name: "asc" },
    });
    res.json({ success: true, data: items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi lấy thực đơn" });
  }
});

// GET /api/menu/:id
router.get("/:id", async (req, res) => {
  try {
    const item = await prisma.menuItem.findUnique({
      where: { id: req.params.id },
      include: { category: true },
    });
    if (!item) return res.status(404).json({ success: false, message: "Không tìm thấy món" });
    res.json({ success: true, data: item });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi lấy chi tiết món" });
  }
});

// POST /api/menu (admin) — tạo món mới
router.post("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { name, description, price, imageUrl, categoryId } = req.body;
    const item = await prisma.menuItem.create({
      data: { name, description, price: Number(price), imageUrl, categoryId },
    });
    res.json({ success: true, data: item });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi tạo món" });
  }
});

// PUT /api/menu/:id (admin) — cập nhật món
router.put("/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { name, description, price, imageUrl, categoryId, available } = req.body;
    const item = await prisma.menuItem.update({
      where: { id: req.params.id },
      data: {
        ...(name !== undefined ? { name } : {}),
        ...(description !== undefined ? { description } : {}),
        ...(price !== undefined ? { price: Number(price) } : {}),
        ...(imageUrl !== undefined ? { imageUrl } : {}),
        ...(categoryId !== undefined ? { categoryId } : {}),
        ...(available !== undefined ? { available } : {}),
      },
    });
    res.json({ success: true, data: item });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi cập nhật món" });
  }
});

// DELETE /api/menu/:id (admin)
router.delete("/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    await prisma.menuItem.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi xóa món" });
  }
});

module.exports = router;
