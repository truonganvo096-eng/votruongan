const express = require("express");
const { PrismaClient } = require("@prisma/client");

const router = express.Router();
const prisma = new PrismaClient();

// POST /api/behavior — ghi lại hành vi: view hoặc add_to_cart
// (hành vi "purchase" được tự động ghi khi tạo đơn hàng, xem routes/orders.js)
router.post("/", async (req, res) => {
  try {
    const { userId, menuItemId, actionType } = req.body;
    if (!menuItemId || !["view", "add_to_cart"].includes(actionType)) {
      return res.status(400).json({ success: false, message: "Dữ liệu không hợp lệ" });
    }
    await prisma.behaviorLog.create({
      data: { userId: userId || null, menuItemId, actionType },
    });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Lỗi khi ghi log hành vi" });
  }
});

module.exports = router;
