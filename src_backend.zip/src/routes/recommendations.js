const express = require("express");
const {
  getFrequentlyBoughtTogether,
  getSimilarItems,
  getForYouRecommendations,
} = require("../services/recommendationService");

const router = express.Router();

// GET /api/recommendations/frequently-bought/:menuItemId
router.get("/frequently-bought/:menuItemId", async (req, res) => {
  try {
    const data = await getFrequentlyBoughtTogether(req.params.menuItemId, 3);
    res.json({ success: true, data });
  } catch (err) {
    console.error("frequently-bought error:", err);
    res.status(500).json({ success: false, message: "Lỗi khi lấy gợi ý" });
  }
});

// GET /api/recommendations/similar/:menuItemId
router.get("/similar/:menuItemId", async (req, res) => {
  try {
    const data = await getSimilarItems(req.params.menuItemId, 4);
    res.json({ success: true, data });
  } catch (err) {
    console.error("similar error:", err);
    res.status(500).json({ success: false, message: "Lỗi khi lấy gợi ý" });
  }
});

// GET /api/recommendations/for-you?userId=
router.get("/for-you", async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId || userId === "undefined" || userId === "null") {
      return res
        .status(400)
        .json({ success: false, message: "Thiếu userId" });
    }

    const data = await getForYouRecommendations(userId, 6);
    res.json({ success: true, data });
  } catch (err) {
    console.error("for-you error:", err);
    res.status(500).json({ success: false, message: "Lỗi khi lấy gợi ý" });
  }
});

module.exports = router;